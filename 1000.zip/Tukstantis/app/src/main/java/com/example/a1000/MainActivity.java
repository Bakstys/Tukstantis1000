package com.example.a1000;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Iterator;


public class MainActivity extends Activity {
    TinyDB tinyDB;
    ArrayList<ZaidimasItem> zaidimasList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.setContentView(R.layout.activity_main);
        super.onCreate(savedInstanceState);
    }

    public void naujasZaidimas(View view){
        Intent intent = new Intent(MainActivity.this, NaujasActivity.class);
        startActivity(intent);
    }
    public void testiZaidima(View view){
        Intent intent = new Intent(MainActivity.this, Zaidimas.class);
        startActivity(intent);
    }
    public void istorija(View view){
        Intent intent = new Intent(MainActivity.this, Istorija.class);
        startActivity(intent);
    }
    }
