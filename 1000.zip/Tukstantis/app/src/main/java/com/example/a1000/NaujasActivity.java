package com.example.a1000;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.view.View;
import android.widget.EditText;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;


public class NaujasActivity extends Activity implements Serializable {
    EditText Zaidejas1, Zaidejas2, Zaidejas3, Zaidejas4;
    String zaid1, zaid2, zaid3, zaid4;
    Button mygtukas;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_naujas);
        Zaidejas1 = (EditText) findViewById(R.id.player1);
        Zaidejas2 = (EditText) findViewById(R.id.player2);
        Zaidejas3 = (EditText) findViewById(R.id.player3);
        Zaidejas4 = (EditText) findViewById(R.id.player4);
        mygtukas = (Button) findViewById((R.id.button));
        mygtukas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isEmpty(Zaidejas1) && !isEmpty(Zaidejas2) && !isEmpty(Zaidejas3) && !isEmpty(Zaidejas4)) {
                    Intent intent = new Intent(NaujasActivity.this, Zaidimas.class);
                    ArrayList<ZaidimasItem> zaidimasList = new ArrayList<>();

                    ArrayList<Integer> taskai1 = new ArrayList<>();
                    taskai1.addAll(Arrays.asList(0));
                    final String zaid1 = Zaidejas1.getText().toString();
                    zaidimasList.add(new ZaidimasItem(zaid1, taskai1));


                    ArrayList<Integer> taskai2 = new ArrayList<>();
                    taskai2.addAll(Arrays.asList(0));
                    final String zaid2 = Zaidejas2.getText().toString();
                    zaidimasList.add(new ZaidimasItem(zaid2, taskai2));


                    ArrayList<Integer> taskai3 = new ArrayList<>();
                    taskai3.addAll(Arrays.asList(0));
                    final String zaid3 = Zaidejas3.getText().toString();
                    zaidimasList.add(new ZaidimasItem(zaid3, taskai3));


                    ArrayList<Integer> taskai4 = new ArrayList<>();
                    taskai4.addAll(Arrays.asList(0));
                    final String zaid4 = Zaidejas4.getText().toString();
                    zaidimasList.add(new ZaidimasItem(zaid4, taskai4));

                    intent.putExtra("key", (Serializable) zaidimasList);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }

            private boolean isEmpty(EditText etText) {
                if (etText.getText().toString().trim().length() > 0)
                    return false;

                return true;
            }
}


