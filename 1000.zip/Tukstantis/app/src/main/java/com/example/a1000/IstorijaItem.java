package com.example.a1000;

import java.util.Date;

public class IstorijaItem {
    private String laimetojas;
    private String data;
    private String zaidejuSkaicius;

    public IstorijaItem(String laimetojas,String data,String zaidejuSkaicius)
    {
        this.laimetojas=laimetojas;
        this.data=data;
        this.zaidejuSkaicius=zaidejuSkaicius;
    }
    public String getLaimetojas()
    {
        return laimetojas;
    }
    public String getZaidejuSkaicius()
    {
        return zaidejuSkaicius;
    }
    public String getData()
    {
        return data;
    }

}
