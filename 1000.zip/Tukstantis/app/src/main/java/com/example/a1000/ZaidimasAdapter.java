package com.example.a1000;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ZaidimasAdapter extends RecyclerView.Adapter<ZaidimasAdapter.ZaidimasViewHolder> {
    private ArrayList<ZaidimasItem> mZaidimasList;
    public static class ZaidimasViewHolder extends RecyclerView.ViewHolder{
        public TextView vardas;
        public TextView taskai;
        public Button spausti;
        public EditText ivedimas;

        public ZaidimasViewHolder(@NonNull View itemView) {
            super(itemView);
            //vardas=itemView.findViewById(R.id.VarduListas);
           // taskai=itemView.findViewById(R.id.TaskuListas);
            //ivedimas=itemView.findViewById(R.id.ivedimas);
            //spausti=itemView.findViewById(R.id.playeris);
        }
    }

    public ZaidimasAdapter(ArrayList<ZaidimasItem> zaidimasList)
    {
        mZaidimasList=zaidimasList;
    }

    @NonNull
    @Override
    public ZaidimasViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.game_list,parent,false);
        ZaidimasViewHolder ivh=new ZaidimasViewHolder(v);
        return ivh;
    }


    @Override
    public void onBindViewHolder(@NonNull final ZaidimasViewHolder holder, int position) {
    ZaidimasItem currentItem=mZaidimasList.get(position);
    final Integer taskas=currentItem.taskai.get(0);
    holder.vardas.setText(currentItem.getVardas());
    holder.taskai.setText(((currentItem.getTaskai().toString())));
        //holder.taskai.setText(taskas);
    //holder.taskai.setText(currentItem.getTaskai().get(position));

        holder.spausti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v ) {

                String value= String.valueOf(holder.ivedimas.getText());
                int finalValue=Integer.parseInt(value);
                //mZaidimasList.indexOf(holder.getAdapterPosition());
                //mZaidimasList.add(holder.getAdapterPosition(), (ZaidimasItem) holder.ivedimas.getText());
                Toast.makeText(v.getContext(), "The number is: ", Toast.LENGTH_SHORT).show();//Gaunam kuris buvo paspaustas


                //Toast.makeText(v.getContext(), "The position is: "+holder.getAdapterPosition(), Toast.LENGTH_SHORT).show();//Gaunam kuris buvo paspaustas
            }
    }
    );
    }
    @Override
    public int getItemCount()
    {
        return mZaidimasList.size();
    }

}
