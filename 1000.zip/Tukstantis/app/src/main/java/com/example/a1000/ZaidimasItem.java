package com.example.a1000;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ZaidimasItem implements Serializable {
    private String vardas;
    List<Integer> taskai = new ArrayList<Integer>();


    public ZaidimasItem(String vardas, List<Integer> taskai)
    {
        this.vardas=vardas;
        this.taskai=taskai;
    }



    public String getVardas()
    {
        return vardas;
    }

    public List<Integer> getTaskai()
    {
        return taskai;
    }

}
