package com.example.a1000;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.nfc.tech.IsoDep;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Date;

public class Istorija extends Activity {
    DatabaseHelper myDb = new DatabaseHelper(this);
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mlayoutManager;

    String vardas;
    String zaidejai;
    String data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.istorija);
        myDb = new DatabaseHelper(this);
        ArrayList<IstorijaItem> istorijaList=new ArrayList<>();
        Cursor res = myDb.getAllData();
        StringBuffer buffer = new StringBuffer();
        while (res.moveToNext()) {
            vardas=res.getString(0);
            zaidejai=res.getString(1);
            data=res.getString(2);
            istorijaList.add((new IstorijaItem(vardas,zaidejai,data)));
        }

        mRecyclerView=findViewById(R.id.listas);
        mRecyclerView.setHasFixedSize(true);
        mlayoutManager=new LinearLayoutManager(this);
        mAdapter=new IstorijaAdapter(istorijaList);
        mRecyclerView.setLayoutManager(mlayoutManager);
        mRecyclerView.setAdapter(mAdapter);
    }
}
