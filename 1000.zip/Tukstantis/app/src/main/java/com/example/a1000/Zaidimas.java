package com.example.a1000;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Parcelable;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import static android.content.ContentValues.TAG;

public class Zaidimas extends Activity {
    private RecyclerView mRecyclerView;
    public static final String SHARED_PREFS = "testFile";
    public static final String TEXT1="text1";
    public static final String TEXT2="text2";
    ArrayList<ZaidimasItem> players = new ArrayList<ZaidimasItem>();
    ArrayList<Object> playerObjects = new ArrayList<Object>();
    TinyDB tinyDB;
    public static final String TEXT3="text3";
    public static final String TEXT4="text4";
    public static final String SWITCH1="switch1";
    boolean hasBeenPaused=false;
    private RecyclerView.Adapter mAdapter;

    DatabaseHelper myDb = new DatabaseHelper(this);
    private RecyclerView.LayoutManager mlayoutManager;
    private Button spausti1, spausti2, spausti3, spausti4;
    int pirmas = 0;
    int antras = 0;
    int dydis = 0;
    String listasSpausdinimui;
    ArrayList<ZaidimasItem> zaidimasList = new ArrayList<>();
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    Calendar c = Calendar.getInstance();
    private EditText ivedimas1, ivedimas2, ivedimas3, ivedimas4;
    private TextView vardas1, vardas2, vardas3, vardas4, taskai1, taskai2, taskai3, taskai4;
    private boolean Var1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_list);
        myDb = new DatabaseHelper(this);

        tinyDB = new TinyDB(this);
        Intent i = getIntent();
        zaidimasList = (ArrayList<ZaidimasItem>) i.getSerializableExtra("key");
        //if(tinyDB.getListObject("Listas",ZaidimasItem.class).size()>0) {

       // else {

        //}
        ivedimas1 = this.findViewById(R.id.ivedimas);
        ivedimas2 = this.findViewById(R.id.ivedimas2);
        ivedimas3 = this.findViewById(R.id.ivedimas3);
        ivedimas4 = this.findViewById(R.id.ivedimas4);
        spausti1 = this.findViewById(R.id.playeris);
        spausti2 = this.findViewById(R.id.playeris2);
        spausti3 = this.findViewById(R.id.playeris3);
        spausti4 = this.findViewById(R.id.playeris4);
        vardas1 = this.findViewById(R.id.VarduListas1);
        vardas2 = this.findViewById(R.id.VarduListas2);
        vardas3 = this.findViewById(R.id.VarduListas3);
        vardas4 = this.findViewById(R.id.VarduListas4);
        taskai1 = this.findViewById(R.id.taskuListas1);
        taskai2 = this.findViewById(R.id.taskuListas2);
        taskai3 = this.findViewById(R.id.taskuListas3);
        taskai4 = this.findViewById(R.id.taskuListas4);
        vardas1.setText(zaidimasList.get(0).getVardas());
        vardas2.setText(zaidimasList.get(1).getVardas());
        vardas3.setText(zaidimasList.get(2).getVardas());
        vardas4.setText(zaidimasList.get(3).getVardas());
        taskai1.setText(zaidimasList.get(0).getTaskai().toString());
        taskai2.setText(zaidimasList.get(1).getTaskai().toString());
        taskai3.setText(zaidimasList.get(2).getTaskai().toString());
        taskai4.setText(zaidimasList.get(3).getTaskai().toString());
        final ArrayList<ZaidimasItem> finalZaidimasList = zaidimasList;
        final ArrayList<ZaidimasItem> finalZaidimasList1 = zaidimasList;
        spausti1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isEmpty(ivedimas1)) {
                    String value = ivedimas1.getText().toString();
                    int finalValue = Integer.parseInt(value);
                    dydis = finalZaidimasList.get(0).getTaskai().size();
                    pirmas = finalZaidimasList.get(0).getTaskai().get(dydis - 1);
                    antras = pirmas + finalValue;
                    finalZaidimasList.get(0).getTaskai().add(antras);
                    taskai1.setText(finalZaidimasList1.get(0).getTaskai().toString());
                    ivedimas1.setText("");
                    if (finalZaidimasList.get(0).getTaskai().get(dydis) >= 1000) {
                        Toast.makeText(v.getContext(), "Laimėjo:" + finalZaidimasList.get(0).getVardas(), Toast.LENGTH_LONG).show();
                        String date = sdf.format(c.getTime());
                        myDb.insertData(finalZaidimasList.get(0).getVardas() + "\n" +
                                        finalZaidimasList.get(1).getVardas() + "\n" +
                                        finalZaidimasList.get(2).getVardas() + "\n" +
                                        finalZaidimasList.get(3).getVardas(),
                                finalZaidimasList.get(0).getVardas(), date);
                    }
                } else {
                    Toast.makeText(v.getContext(), "Neįvedėte taškų:", Toast.LENGTH_SHORT).show();
                }
            }
        });
        spausti2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isEmpty(ivedimas2)) {
                    String value = ivedimas2.getText().toString();
                    int finalValue = Integer.parseInt(value);
                    dydis = finalZaidimasList.get(1).getTaskai().size();
                    pirmas = finalZaidimasList.get(1).getTaskai().get(dydis - 1);
                    antras = pirmas + finalValue;
                    finalZaidimasList.get(1).getTaskai().add(antras);
                    taskai2.setText(finalZaidimasList1.get(1).getTaskai().toString());
                    ivedimas2.setText("");
                    if (finalZaidimasList.get(1).getTaskai().get(dydis) >= 1000) {
                        Toast.makeText(v.getContext(), "Laimėjo:" + finalZaidimasList.get(1).getVardas(), Toast.LENGTH_LONG).show();
                        String date = sdf.format(c.getTime());
                        myDb.insertData(finalZaidimasList.get(0).getVardas() + "\n" +
                                        finalZaidimasList.get(1).getVardas() + "\n" +
                                        finalZaidimasList.get(2).getVardas() + "\n" +
                                        finalZaidimasList.get(3).getVardas(),
                                finalZaidimasList.get(1).getVardas(), date);
                    }
                } else {
                    Toast.makeText(v.getContext(), "Neįvedėte taškų:", Toast.LENGTH_SHORT).show();
                }
            }
        });
        spausti3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isEmpty(ivedimas3)) {
                    String value = ivedimas3.getText().toString();
                    int finalValue = Integer.parseInt(value);
                    dydis = finalZaidimasList.get(2).getTaskai().size();
                    pirmas = finalZaidimasList.get(2).getTaskai().get(dydis - 1);
                    antras = pirmas + finalValue;
                    finalZaidimasList.get(2).getTaskai().add(antras);
                    taskai3.setText(finalZaidimasList1.get(2).getTaskai().toString());
                    ivedimas3.setText("");
                    if (finalZaidimasList.get(2).getTaskai().get(dydis) >= 1000) {
                        Toast.makeText(v.getContext(), "Laimėjo:" + finalZaidimasList.get(2).getVardas(), Toast.LENGTH_LONG).show();
                        String date = sdf.format(c.getTime());
                        myDb.insertData(finalZaidimasList.get(0).getVardas() + "\n" +
                                        finalZaidimasList.get(1).getVardas() + "\n" +
                                        finalZaidimasList.get(2).getVardas() + "\n" +
                                        finalZaidimasList.get(3).getVardas(),
                                finalZaidimasList.get(2).getVardas(), date);
                    }
                } else {
                    Toast.makeText(v.getContext(), "Neįvedėte taškų:", Toast.LENGTH_SHORT).show();
                }
            }
        });
        spausti4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isEmpty(ivedimas4)) {
                    String value = ivedimas4.getText().toString();
                    int finalValue = Integer.parseInt(value);
                    dydis = finalZaidimasList.get(3).getTaskai().size();
                    pirmas = finalZaidimasList.get(3).getTaskai().get(dydis - 1);
                    antras = pirmas + finalValue;
                    finalZaidimasList.get(3).getTaskai().add(antras);
                    taskai4.setText(finalZaidimasList1.get(3).getTaskai().toString());
                    ivedimas4.setText("");
                    if (finalZaidimasList.get(3).getTaskai().get(dydis) >= 1000) {
                        Toast.makeText(v.getContext(), "Laimėjo:" + finalZaidimasList.get(3).getVardas(), Toast.LENGTH_LONG).show();
                        String date = sdf.format(c.getTime());
                        myDb.insertData(finalZaidimasList.get(0).getVardas() + "\n" +
                                        finalZaidimasList.get(1).getVardas() + "\n" +
                                        finalZaidimasList.get(2).getVardas() + "\n" +
                                        finalZaidimasList.get(3).getVardas(),
                                finalZaidimasList.get(3).getVardas(), date);

                    }
                } else {
                    Toast.makeText(v.getContext(), "Neįvedėte taškų:", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isEmpty(EditText etText) {
        if (etText.getText().toString().trim().length() > 0)
            return false;
        return true;
    }

    public void saveData(ArrayList<ZaidimasItem> Listas)
    {
        ArrayList<Object> playerObjects = new ArrayList<Object>();
        for(ZaidimasItem a : Listas){
            playerObjects.add((Object)a);
        }
        tinyDB.putListObject("Listas",playerObjects);
    }
    public void LoadData()
    {
        ArrayList<Object> players=tinyDB.getListObject("Listas",ZaidimasItem.class);
        Iterator it=players.iterator();
        while(it.hasNext())
        {
            zaidimasList.add((ZaidimasItem) it.next());
        }
    }

    public void onPause() {
        super.onPause();
        saveData(zaidimasList);
        hasBeenPaused = true;
    }
    public void onResume() {
        super.onResume();
        LoadData();
    }
    }