package com.example.a1000;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class IstorijaAdapter extends RecyclerView.Adapter<IstorijaAdapter.IstorijaViewHolder> {
    private ArrayList<IstorijaItem> mIstorijaList;
    public static class IstorijaViewHolder extends RecyclerView.ViewHolder{
        public TextView laimetojas;
        public TextView data;
        public TextView zaidejuSkaicius;
        public IstorijaViewHolder(@NonNull View itemView) {
            super(itemView);
            data=itemView.findViewById(R.id.istorija1);
            laimetojas=itemView.findViewById(R.id.istorija2);
            zaidejuSkaicius=itemView.findViewById(R.id.istorija3);
        }
    }
    public IstorijaAdapter(ArrayList<IstorijaItem> istorijaList){
        mIstorijaList=istorijaList;
    }

    @NonNull
    @Override
    public IstorijaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.istorija_list,parent,false);
        IstorijaViewHolder ivh=new IstorijaViewHolder(v);
        return ivh;
    }

    @Override
    public void onBindViewHolder(@NonNull IstorijaViewHolder holder, int position) {
    IstorijaItem currentItem=mIstorijaList.get(position);
    holder.laimetojas.setText(currentItem.getLaimetojas());
    holder.data.setText(currentItem.getData());
    holder.zaidejuSkaicius.setText(String.valueOf(currentItem.getZaidejuSkaicius()));

    }

    @Override
    public int getItemCount() {
        return mIstorijaList.size();
    }
}
