package com.example.gson;

public class MyClass {
}
